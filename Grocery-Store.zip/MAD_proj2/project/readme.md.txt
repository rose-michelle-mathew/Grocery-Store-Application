Download the Zip file
Unzip the file 
open app.py file on any editor
download the required dependencies if any for FLask, Sqlalchemy, Flask-Alchemy etc.
open the file path on cmd
run the python file using the command "python app.py"
Click on the url that is generated.